For now api, Twitter have different token, but we can classify them into two types:

- App Access Token
- User Access Token

I assume that you have initialized two Api instances to get data from Twitter.

one is variable `my_api`(instance with your user access token)

Another is `api`(instance with app access token).

Now let's go!
